from time import sleep
from orbit import ISS
from skyfield.api import load

ephemeris = load('de421.bsp')
timescale = load.timescale()

while True:
    t = timescale.now()
    if ISS.at(t).is_sunlit(ephemeris):
        print("THERE IS LIGHT")
    else:
        print("DARKNESS")
    sleep(1)
